import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings extends ChangeNotifier {
  AppSettings(this._p, this.locale, this.themeMode);
  final SharedPreferences _p;
  Locale locale;
  ThemeMode themeMode;

  static Future<AppSettings> load() async {
    final p = await SharedPreferences.getInstance();
    final lang = p.getString('lang') ??
        (WidgetsBinding.instance.platformDispatcher.locale.languageCode == 'ar' ? 'ar' : 'en');
    final theme = ThemeMode.values[p.getInt('theme') ?? ThemeMode.system.index];
    return AppSettings(p, Locale(lang), theme);
  }

  void setLocale(String code) {
    locale = Locale(code);
    _p.setString('lang', code);
    notifyListeners();
  }

  void setThemeMode(ThemeMode m) {
    themeMode = m;
    _p.setInt('theme', m.index);
    notifyListeners();
  }
}
