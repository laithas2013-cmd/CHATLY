import 'package:flutter/material.dart';

const _m = <String, Map<String, String>>{
  'en': {
    'tagline': 'Chat with the people you love',
    'google': 'Continue with Google',
    'setupTitle': 'Set up your profile',
    'name': 'Display name',
    'username': 'Username',
    'usernameHelp': '3-20 characters: letters, numbers, underscore',
    'usernameInvalid': 'Invalid username',
    'usernameTaken': 'This username is already taken',
    'nameRequired': 'Please enter your name',
    'save': 'Save and continue',
    'changePhoto': 'Choose photo',
    'welcome': 'Welcome',
    'signOut': 'Sign out',
    'light': 'Light',
    'dark': 'Dark',
    'system': 'System',
    'errNetwork': 'No connection. Check your internet and try again.',
    'errGeneric': 'Something went wrong. Please try again.',
    'errPhoto': 'Could not upload the photo.',
  },
  'ar': {
    'tagline': 'تحدّث مع من تحب',
    'google': 'المتابعة باستخدام Google',
    'setupTitle': 'أكمل ملفك الشخصي',
    'name': 'الاسم',
    'username': 'اسم المستخدم',
    'usernameHelp': '٣-٢٠ حرفاً: أحرف إنجليزية وأرقام وشرطة سفلية',
    'usernameInvalid': 'اسم مستخدم غير صالح',
    'usernameTaken': 'اسم المستخدم مستخدم بالفعل',
    'nameRequired': 'الرجاء إدخال الاسم',
    'save': 'حفظ ومتابعة',
    'changePhoto': 'اختيار صورة',
    'welcome': 'مرحباً',
    'signOut': 'تسجيل الخروج',
    'light': 'نهاري',
    'dark': 'ليلي',
    'system': 'حسب الجهاز',
    'errNetwork': 'لا يوجد اتصال. تحقق من الإنترنت وحاول مجدداً.',
    'errGeneric': 'حدث خطأ. حاول مرة أخرى.',
    'errPhoto': 'تعذّر رفع الصورة.',
  },
};

String tr(BuildContext c, String key) {
  final code = Localizations.localeOf(c).languageCode;
  return _m[code]?[key] ?? _m['en']![key] ?? key;
}
