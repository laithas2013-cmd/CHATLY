import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'strings.dart';

String friendlyError(BuildContext c, Object e) {
  if (e is FirebaseAuthException && e.code == 'network-request-failed') {
    return tr(c, 'errNetwork');
  }
  if (e is FirebaseException &&
      (e.code == 'unavailable' || e.code == 'network-request-failed' || e.code == 'deadline-exceeded')) {
    return tr(c, 'errNetwork');
  }
  return tr(c, 'errGeneric');
}

void showError(BuildContext c, Object e) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(friendlyError(c, e))));
}
