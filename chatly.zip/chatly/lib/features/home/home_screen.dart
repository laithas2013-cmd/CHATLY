import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/settings.dart';
import '../../core/strings.dart';
import '../auth/auth_service.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.profile});
  final Map<String, dynamic> profile;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final photo = profile['photoUrl'] as String?;
    return Scaffold(
      appBar: AppBar(
        title: const Text('CHATLY'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.settings),
            onSelected: (v) {
              switch (v) {
                case 'ar':
                case 'en':
                  s.setLocale(v);
                  break;
                case 'light':
                  s.setThemeMode(ThemeMode.light);
                  break;
                case 'dark':
                  s.setThemeMode(ThemeMode.dark);
                  break;
                case 'system':
                  s.setThemeMode(ThemeMode.system);
                  break;
                case 'out':
                  AuthService().signOut();
                  break;
              }
            },
            itemBuilder: (c) => [
              const PopupMenuItem(value: 'ar', child: Text('العربية')),
              const PopupMenuItem(value: 'en', child: Text('English')),
              const PopupMenuDivider(),
              PopupMenuItem(value: 'light', child: Text(tr(c, 'light'))),
              PopupMenuItem(value: 'dark', child: Text(tr(c, 'dark'))),
              PopupMenuItem(value: 'system', child: Text(tr(c, 'system'))),
              const PopupMenuDivider(),
              PopupMenuItem(value: 'out', child: Text(tr(c, 'signOut'))),
            ],
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 48,
              backgroundImage: photo != null ? NetworkImage(photo) : null,
              child: photo == null ? const Icon(Icons.person, size: 44) : null,
            ),
            const SizedBox(height: 16),
            Text('${tr(context, 'welcome')}, ${profile['displayName']}',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            Text('@${profile['username']}', textDirection: TextDirection.ltr),
          ],
        ),
      ),
    );
  }
}
