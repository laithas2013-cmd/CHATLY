import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/errors.dart';
import '../../core/strings.dart';
import 'profile_service.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key, required this.user});
  final User user;
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name = TextEditingController(text: widget.user.displayName ?? '');
  final _username = TextEditingController();
  File? _photo;
  bool _busy = false;
  bool _taken = false;

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 800, imageQuality: 85);
    if (x != null) setState(() => _photo = File(x.path));
  }

  Future<void> _save() async {
    setState(() => _taken = false);
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    final svc = ProfileService();
    try {
      String? url = widget.user.photoURL;
      if (_photo != null) {
        try {
          url = await svc.uploadAvatar(widget.user.uid, _photo!);
        } catch (_) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr(context, 'errPhoto'))));
          }
        }
      }
      await svc.saveProfile(
        uid: widget.user.uid,
        displayName: _name.text,
        username: _username.text.trim(),
        photoUrl: url,
      );
    } on UsernameTakenException {
      if (mounted) {
        setState(() => _taken = true);
        _form.currentState!.validate();
      }
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ImageProvider? avatar = _photo != null
        ? FileImage(_photo!)
        : (widget.user.photoURL != null ? NetworkImage(widget.user.photoURL!) : null);
    return Scaffold(
      appBar: AppBar(title: Text(tr(context, 'setupTitle'))),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            Center(
              child: GestureDetector(
                onTap: _pick,
                child: CircleAvatar(
                  radius: 52,
                  backgroundImage: avatar,
                  child: avatar == null ? const Icon(Icons.person, size: 48) : null,
                ),
              ),
            ),
            TextButton(onPressed: _pick, child: Text(tr(context, 'changePhoto'))),
            const SizedBox(height: 12),
            Form(
              key: _form,
              child: Column(
                children: [
                  TextFormField(
                    controller: _name,
                    decoration: InputDecoration(labelText: tr(context, 'name')),
                    validator: (v) => (v == null || v.trim().isEmpty) ? tr(context, 'nameRequired') : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _username,
                    textDirection: TextDirection.ltr,
                    autocorrect: false,
                    decoration: InputDecoration(
                      labelText: tr(context, 'username'),
                      prefixText: '@',
                      helperText: tr(context, 'usernameHelp'),
                    ),
                    onChanged: (_) {
                      if (_taken) setState(() => _taken = false);
                    },
                    validator: (v) {
                      if (!usernameRegex.hasMatch((v ?? '').trim().toLowerCase())) {
                        return tr(context, 'usernameInvalid');
                      }
                      if (_taken) return tr(context, 'usernameTaken');
                      return null;
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),
            FilledButton(
              onPressed: _busy ? null : _save,
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(tr(context, 'save')),
            ),
          ],
        ),
      ),
    );
  }
}
