import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class UsernameTakenException implements Exception {}

final usernameRegex = RegExp(r'^[a-z0-9_]{3,20}$');

class ProfileService {
  final _db = FirebaseFirestore.instance;

  /// Atomically claims the username (usernames/{name} -> uid) and writes the profile.
  Future<void> saveProfile({
    required String uid,
    required String displayName,
    required String username,
    String? photoUrl,
  }) async {
    final name = username.toLowerCase();
    final userRef = _db.collection('users').doc(uid);
    final newRef = _db.collection('usernames').doc(name);

    await _db.runTransaction((tx) async {
      final userSnap = await tx.get(userRef);
      final newSnap = await tx.get(newRef);
      final oldName = userSnap.data()?['username'] as String?;

      if (newSnap.exists && newSnap.data()?['uid'] != uid) {
        throw UsernameTakenException();
      }
      if (!newSnap.exists) {
        tx.set(newRef, {'uid': uid});
      }
      if (oldName != null && oldName != name) {
        tx.delete(_db.collection('usernames').doc(oldName));
      }
      tx.set(
        userRef,
        {
          'uid': uid,
          'displayName': displayName.trim(),
          'username': name,
          if (photoUrl != null) 'photoUrl': photoUrl,
          'profileComplete': true,
          if (!userSnap.exists) 'createdAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
    });
  }

  Future<String> uploadAvatar(String uid, File file) async {
    final ref = FirebaseStorage.instance.ref('avatars/$uid/avatar.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    return ref.getDownloadURL();
  }
}
