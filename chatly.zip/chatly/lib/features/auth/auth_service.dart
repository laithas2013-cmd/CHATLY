import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  final _auth = FirebaseAuth.instance;
  final _google = GoogleSignIn();

  /// Returns null if the user cancelled.
  Future<UserCredential?> signInWithGoogle() async {
    final acc = await _google.signIn();
    if (acc == null) return null;
    final tok = await acc.authentication;
    final cred = GoogleAuthProvider.credential(
      accessToken: tok.accessToken,
      idToken: tok.idToken,
    );
    return _auth.signInWithCredential(cred);
  }

  Future<void> signOut() async {
    await _google.signOut();
    await _auth.signOut();
  }
}
