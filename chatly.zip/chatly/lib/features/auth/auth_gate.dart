import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../home/home_screen.dart';
import '../profile/setup_screen.dart';
import 'login_screen.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final user = snap.data;
        if (user == null) return const LoginScreen();
        return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
          builder: (context, ds) {
            if (ds.hasError) {
              return Scaffold(body: Center(child: Text('${ds.error}')));
            }
            if (!ds.hasData) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            }
            final data = ds.data!.data();
            if (data == null || data['profileComplete'] != true) {
              return SetupScreen(user: user);
            }
            return HomeScreen(profile: data);
          },
        );
      },
    );
  }
}
