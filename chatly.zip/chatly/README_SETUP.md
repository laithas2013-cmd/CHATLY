# CHATLY — Phase 1 (Auth + Profile + Username)

Status: code written but NOT yet compiled or run on a device (no Flutter SDK was
available where it was generated). Treat it as untested until you complete step 6.

## 1) Generate the Android shell
    flutter create --org com.chatly --project-name chatly --platforms android .
This keeps lib/, pubspec.yaml and rules files; package id becomes com.chatly.chatly.
Then: flutter pub get

## 2) Firebase project
1. console.firebase.google.com -> Add project.
2. Add Android app, package name `com.chatly.chatly`.
3. Add SHA-1 and SHA-256 of your debug key:
   cd android && ./gradlew signingReport
4. Download google-services.json -> android/app/google-services.json (never commit it).
5. Build -> Authentication -> Sign-in method -> enable Google.
6. Build -> Firestore Database -> create (production mode). Build -> Storage -> create.
7. Deploy rules: npm i -g firebase-tools && firebase login && firebase deploy --only firestore:rules,storage

## 3) Gradle (Google services plugin)
android/settings.gradle(.kts): add plugin
    id("com.google.gms.google-services") version "4.4.2" apply false
android/app/build.gradle(.kts): add in plugins
    id("com.google.gms.google-services")
Set minSdk to 23 (android/app/build.gradle: minSdk = 23).

## 4) Run on a device
    flutter run
## 5) Build APK
    flutter build apk --release   # output: build/app/outputs/flutter-apk/app-release.apk
    adb install build/app/outputs/flutter-apk/app-release.apk
## 6) Phase 1 test checklist (two real accounts, two devices)
- Google sign-in works on both; profile screen appears on first login.
- Account A takes username `test_a`; account B trying `test_a` sees "already taken".
- Photo uploads and shows on Home; restart app -> stays signed in.
- Switch language AR/EN (RTL flips), switch dark/light, sign out/in.
- Airplane mode -> sign-in/save shows the connection message.
